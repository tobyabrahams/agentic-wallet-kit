# Agent Skills

This file describes the capabilities and boundaries of the local agent wallet system.

## Core capabilities

- Create a new Solana wallet programmatically
- Request devnet SOL for a fresh wallet
- Hold SOL
- Mint and hold demo SPL tokens
- Build and sign transactions automatically
- Simulate transactions before broadcast
- Enforce policy checks before signing
- Run isolated actions for multiple agents independently

## Supported actions

### 1. Wallet bootstrap
Inputs:
- agent name
- strategy label

Outputs:
- agent id
- public key
- local secret key record
- spend cap

### 2. Devnet funding
Inputs:
- public key
- desired SOL amount

Outputs:
- airdrop signature

### 3. Demo token minting
Inputs:
- mint authority keypair
- recipient public key

Outputs:
- mint address
- associated token account address
- mint transaction signature

### 4. Safe SOL transfer
Inputs:
- signer keypair
- destination public key
- amount in SOL
- optional destination allowlist

Outputs:
- confirmed transaction signature on success
- blocked reason on failure

## Guardrails

- Transactions are evaluated before signing
- Spend cap is enforced per transaction
- Program allowlist can be enforced through environment variables
- Destination allowlist can be checked for transfers
- Simulation is attempted before send

## Known limitations

- Secret keys are stored locally for demo purposes only
- The demo flow uses simple scripted logic, not a live LLM planner
- The UI does not yet stream live Explorer events
- There is no hardware security module or MPC layer

## Best use in the bounty

Use this agent system to demonstrate:

- multiple agents with separate wallets
- one valid autonomous action
- one blocked risky action
- visible separation between agent logic and wallet execution
