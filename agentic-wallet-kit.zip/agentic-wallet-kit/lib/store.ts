import fs from "fs";
import path from "path";
import { AgentAction, AgentRecord } from "./types";

const dataDir = path.join(process.cwd(), ".data");
const agentsPath = path.join(dataDir, "agents.json");
const actionsPath = path.join(dataDir, "actions.json");

function ensureDir() {
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
}

function readJson<T>(file: string, fallback: T): T {
  ensureDir();
  if (!fs.existsSync(file)) return fallback;
  return JSON.parse(fs.readFileSync(file, "utf8")) as T;
}

function writeJson<T>(file: string, value: T) {
  ensureDir();
  fs.writeFileSync(file, JSON.stringify(value, null, 2));
}

export function getAgents(): AgentRecord[] {
  return readJson<AgentRecord[]>(agentsPath, []);
}

export function saveAgent(agent: AgentRecord) {
  const agents = getAgents();
  agents.push(agent);
  writeJson(agentsPath, agents);
}

export function getActions(): AgentAction[] {
  return readJson<AgentAction[]>(actionsPath, []);
}

export function saveAction(action: AgentAction) {
  const actions = getActions();
  actions.unshift(action);
  writeJson(actionsPath, actions.slice(0, 50));
}
