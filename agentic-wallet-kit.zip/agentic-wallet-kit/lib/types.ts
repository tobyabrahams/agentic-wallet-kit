export type AgentStrategy = "treasury" | "rebalance" | "lp-demo";

export type AgentRecord = {
  id: string;
  name: string;
  publicKey: string;
  secretKey: number[];
  createdAt: string;
  strategy: AgentStrategy;
  spendLimitSol: number;
};

export type AgentAction = {
  agentId: string;
  kind: "airdrop" | "sol-transfer" | "mint-token" | "blocked";
  note: string;
  signature?: string;
  blockedReason?: string;
  createdAt: string;
};
