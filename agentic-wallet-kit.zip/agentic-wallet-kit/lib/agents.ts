import { Keypair, PublicKey } from "@solana/web3.js";
import { createProgrammaticWallet, mintDemoToken, requestDevnetAirdrop, safeTransferSol } from "./solana";
import { getAgents, saveAction, saveAgent } from "./store";
import { AgentRecord, AgentStrategy } from "./types";

export function bootstrapAgent(name: string, strategy: AgentStrategy): AgentRecord {
  const keypair = createProgrammaticWallet();
  const agent: AgentRecord = {
    id: crypto.randomUUID(),
    name,
    publicKey: keypair.publicKey.toBase58(),
    secretKey: Array.from(keypair.secretKey),
    createdAt: new Date().toISOString(),
    strategy,
    spendLimitSol: Number(process.env.POLICY_MAX_SOL_PER_TX ?? "0.5"),
  };
  saveAgent(agent);
  return agent;
}

export async function runAgentScenario(agentId: string) {
  const agent = getAgents().find((item) => item.id === agentId);
  if (!agent) {
    throw new Error("Agent not found.");
  }

  const signer = Keypair.fromSecretKey(Uint8Array.from(agent.secretKey));

  const airdropSig = await requestDevnetAirdrop(signer.publicKey, 1);
  saveAction({
    agentId,
    kind: "airdrop",
    note: `${agent.name} received devnet SOL.`,
    signature: airdropSig,
    createdAt: new Date().toISOString(),
  });

  const tokenResult = await mintDemoToken(signer, signer.publicKey);
  saveAction({
    agentId,
    kind: "mint-token",
    note: `${agent.name} minted demo SPL tokens.`,
    signature: tokenResult.signature,
    createdAt: new Date().toISOString(),
  });

  const destination = Keypair.generate().publicKey;
  const transfer = await safeTransferSol({
    signer,
    destination,
    amountSol: 0.25,
    allowlist: [destination.toBase58()],
  });

  if (transfer.ok) {
    saveAction({
      agentId,
      kind: "sol-transfer",
      note: `${agent.name} executed a policy-approved SOL transfer.`,
      signature: transfer.signature,
      createdAt: new Date().toISOString(),
    });
  }

  const blockedDestination = new PublicKey("11111111111111111111111111111111");
  const blocked = await safeTransferSol({
    signer,
    destination: blockedDestination,
    amountSol: 0.75,
    allowlist: [],
  });

  if (!blocked.ok) {
    saveAction({
      agentId,
      kind: "blocked",
      note: `${agent.name} attempted a risky transaction.`,
      blockedReason: blocked.reason,
      createdAt: new Date().toISOString(),
    });
  }

  return { airdropSig, tokenResult, transfer, blocked };
}
