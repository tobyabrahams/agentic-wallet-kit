import {
  clusterApiUrl,
  Connection,
  Keypair,
  LAMPORTS_PER_SOL,
  PublicKey,
  SystemProgram,
  Transaction,
  sendAndConfirmTransaction,
} from "@solana/web3.js";
import {
  createMint,
  getOrCreateAssociatedTokenAccount,
  mintTo,
} from "@solana/spl-token";
import { evaluateTransactionPolicy, isAllowedDestination } from "./policy";

export function getConnection() {
  const endpoint = process.env.SOLANA_RPC_URL || clusterApiUrl("devnet");
  return new Connection(endpoint, "confirmed");
}

export function createProgrammaticWallet() {
  return Keypair.generate();
}

export async function requestDevnetAirdrop(publicKey: PublicKey, sol = 1) {
  const connection = getConnection();
  const signature = await connection.requestAirdrop(publicKey, sol * LAMPORTS_PER_SOL);
  await connection.confirmTransaction(signature, "confirmed");
  return signature;
}

export async function safeTransferSol(params: {
  signer: Keypair;
  destination: PublicKey;
  amountSol: number;
  allowlist?: string[];
}) {
  const connection = getConnection();
  const tx = new Transaction().add(
    SystemProgram.transfer({
      fromPubkey: params.signer.publicKey,
      toPubkey: params.destination,
      lamports: params.amountSol * LAMPORTS_PER_SOL,
    })
  );

  const destinationCheck = isAllowedDestination(params.destination, params.allowlist ?? []);
  if (!destinationCheck.ok) return destinationCheck;

  const policy = evaluateTransactionPolicy(tx);
  if (!policy.ok) return policy;

  const simulation = await connection.simulateTransaction(tx, [params.signer]);
  if (simulation.value.err) {
    return { ok: false as const, reason: `Simulation failed: ${JSON.stringify(simulation.value.err)}` };
  }

  const signature = await sendAndConfirmTransaction(connection, tx, [params.signer]);
  return { ok: true as const, signature };
}

export async function mintDemoToken(authority: Keypair, recipient: PublicKey) {
  const connection = getConnection();
  const mint = await createMint(connection, authority, authority.publicKey, null, 6);
  const recipientAta = await getOrCreateAssociatedTokenAccount(connection, authority, mint, recipient);
  const signature = await mintTo(connection, authority, mint, recipientAta.address, authority, 250_000_000);
  return { mint: mint.toBase58(), tokenAccount: recipientAta.address.toBase58(), signature };
}
