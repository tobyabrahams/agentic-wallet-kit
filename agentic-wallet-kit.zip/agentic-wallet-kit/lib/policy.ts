import { PublicKey, SystemProgram, Transaction } from "@solana/web3.js";

export type PolicyResult =
  | { ok: true }
  | { ok: false; reason: string };

const allowedProgramIds = (process.env.POLICY_ALLOWED_PROGRAM_IDS ?? "")
  .split(",")
  .map((value) => value.trim())
  .filter(Boolean);

const maxSolPerTx = Number(process.env.POLICY_MAX_SOL_PER_TX ?? "0.5");

export function evaluateTransactionPolicy(transaction: Transaction): PolicyResult {
  for (const instruction of transaction.instructions) {
    const programId = instruction.programId.toBase58();
    if (allowedProgramIds.length > 0 && !allowedProgramIds.includes(programId)) {
      return { ok: false, reason: `Program ${programId} is not allowlisted.` };
    }

    if (instruction.programId.equals(SystemProgram.programId) && instruction.data[0] === 2) {
      const lamports = instruction.data.readBigUInt64LE(4);
      const amountSol = Number(lamports) / 1_000_000_000;
      if (amountSol > maxSolPerTx) {
        return { ok: false, reason: `Transfer exceeds spend cap of ${maxSolPerTx} SOL.` };
      }
    }
  }

  return { ok: true };
}

export function isAllowedDestination(destination: PublicKey, allowlist: string[]): PolicyResult {
  if (allowlist.length === 0) return { ok: true };
  if (!allowlist.includes(destination.toBase58())) {
    return { ok: false, reason: `Destination ${destination.toBase58()} is not in the allowlist.` };
  }
  return { ok: true };
}
