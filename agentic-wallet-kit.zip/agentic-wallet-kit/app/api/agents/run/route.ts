import { NextResponse } from "next/server";
import { runAgentScenario } from "@/lib/agents";

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  if (!body.agentId || typeof body.agentId !== "string") {
    return NextResponse.json({ error: "agentId is required." }, { status: 400 });
  }

  try {
    const result = await runAgentScenario(body.agentId);
    return NextResponse.json({ result });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Unknown error." },
      { status: 500 }
    );
  }
}
