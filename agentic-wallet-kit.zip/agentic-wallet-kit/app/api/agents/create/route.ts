import { NextResponse } from "next/server";
import { bootstrapAgent } from "@/lib/agents";
import { AgentStrategy } from "@/lib/types";

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const name = typeof body.name === "string" && body.name ? body.name : "Treasury Agent";
  const strategy = (["treasury", "rebalance", "lp-demo"] as AgentStrategy[]).includes(body.strategy)
    ? body.strategy
    : "treasury";

  const agent = bootstrapAgent(name, strategy);
  return NextResponse.json({ agent });
}
