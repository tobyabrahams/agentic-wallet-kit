import { DashboardShell } from "@/components/dashboard";

const features = [
  ["Programmatic wallets", "Each agent gets an isolated Solana wallet created in code."],
  ["Automatic signing", "Transactions are assembled, simulated, checked, then signed without manual approval."],
  ["SOL and SPL support", "The demo handles SOL airdrops and mints demo SPL tokens for each agent."],
  ["Policy engine", "Spend caps and allowlists give the judges a visible security story."],
];

export default function HomePage() {
  return (
    <main>
      <section style={{ padding: "56px 0 28px", borderBottom: "1px solid #e5e7eb" }}>
        <div className="container">
          <div className="badge">Superteam Nigeria • Agentic Wallets for AI Agents</div>
          <h1 style={{ fontSize: 68, lineHeight: 0.96, maxWidth: 940, margin: "18px 0 0", letterSpacing: "-0.05em" }}>
            A submission kit that feels like a product, not a last-minute bounty repo.
          </h1>
          <p style={{ maxWidth: 900, fontSize: 20, lineHeight: 1.8, color: "#4b5563", marginTop: 20 }}>
            This starter includes a polished front end, API routes, programmatic wallet creation, devnet airdrop flow, demo SPL minting,
            policy-based transaction checks, and the documentation package the challenge asks for.
          </p>
          <div style={{ display: "flex", gap: 12, marginTop: 24, flexWrap: "wrap" }}>
            <a className="btn" href="#demo">Jump to demo</a>
            <a className="btn secondary" href="#docs">Open docs checklist</a>
          </div>
        </div>
      </section>

      <section style={{ padding: "32px 0 20px" }}>
        <div className="container grid" style={{ gridTemplateColumns: "repeat(4, minmax(0, 1fr))" }}>
          {features.map(([title, text]) => (
            <div className="card" key={title} style={{ padding: 22 }}>
              <div style={{ fontSize: 20, fontWeight: 700 }}>{title}</div>
              <p className="small" style={{ marginTop: 10, lineHeight: 1.8 }}>{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="demo" style={{ padding: "20px 0 32px" }}>
        <div className="container">
          <DashboardShell />
        </div>
      </section>

      <section id="docs" style={{ padding: "12px 0 72px" }}>
        <div className="container grid" style={{ gridTemplateColumns: "1fr 1fr" }}>
          <div className="card" style={{ padding: 28 }}>
            <div className="small">Submission checklist</div>
            <ul style={{ marginTop: 16, lineHeight: 2 }}>
              <li>Working devnet prototype</li>
              <li>Programmatic wallet creation</li>
              <li>Automatic signing with policy checks</li>
              <li>SOL and SPL token support</li>
              <li>Test dApp or demo protocol interaction</li>
              <li>README, deep dive, and SKILLS.md</li>
            </ul>
          </div>
          <div className="card" style={{ padding: 28 }}>
            <div className="small">Recommended repo story</div>
            <div className="code" style={{ marginTop: 16 }}>
{`app/
  api/agents/create/route.ts
  api/agents/run/route.ts
  page.tsx
lib/
  solana.ts
  policy.ts
  agents.ts
  store.ts
docs/
  deep-dive.md
README.md
SKILLS.md`}
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
