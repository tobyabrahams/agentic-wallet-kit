# Deep Dive: Agentic Wallets for AI Agents on Solana

## Goal

The point of this prototype is simple.
An AI agent should be able to act on Solana without a human manually signing every action.
But the wallet layer should still stay strict about what the agent is allowed to do.

So the architecture separates **decision-making** from **wallet execution**.

## Architecture

### 1. Agent layer

This layer decides intent.
It can be a bot, scheduler, rules engine, or local AI simulation.
It does not touch raw signing keys directly.

Examples of intent:

- request initial devnet funding
- mint demo tokens
- transfer a small amount of SOL
- rebalance toward a target state

### 2. Wallet core

This layer owns the execution path.
It:

- creates wallets programmatically
- builds transactions
- simulates them
- checks policy
- signs automatically only if the transaction passes policy
- submits the transaction to devnet

This separation matters because it keeps agent logic replaceable while wallet controls remain stable.

### 3. Policy engine

The policy engine is where safety becomes visible.
For this prototype it enforces:

- per-transaction SOL spend caps
- optional destination allowlists
- program allowlists from environment variables

The core idea is that an agent can be autonomous without being unrestricted.

### 4. Interface layer

The dashboard exists for judges.
A strong bounty submission should make the system easy to understand in a few minutes.
So the UI should show:

- wallet addresses
- balances
- current strategy
- latest actions
- blocked action reasons

## Security considerations

### Key management

For a real system, local plaintext secret key storage is not enough.
This repo uses local file storage only because the bounty asks for a working prototype.
A stronger production path would use:

- encrypted key storage
- HSM or enclave-backed signing
- MPC or delegated signing
- short-lived session authorities where appropriate

### Simulation before send

Transactions are simulated before broadcast so the system can catch obvious failures before spending fees or producing noisy onchain errors.

### Policy before signing

The key idea is not just “sign automatically.”
It is “sign automatically after checks.”
That is the difference between agentic execution and reckless execution.

## How the demo works

1. Create an agent wallet in code
2. Request devnet SOL
3. Mint demo SPL tokens to the agent
4. Execute a safe SOL transfer
5. Attempt a second transfer that exceeds the spend cap
6. Block that risky transfer before signing

This gives the judges both a success path and a failure path.
That makes the security story much easier to trust.

## Scalability

The design supports multiple agents because each one has:

- its own keypair
- its own state record
- its own strategy label
- its own action history

That is enough for a prototype multi-agent test harness.
A more complete version could add job queues, per-agent policy profiles, and external data feeds.

## Why this is a good fit for the challenge

The challenge asks for:

- programmatic wallet creation
- automatic signing
- SOL or SPL token support
- interaction with a test dApp or protocol
- clear documentation
- multi-agent scalability

This prototype hits the core path and leaves room for further polish without turning the scope into a mess.
