"use client";

import { useMemo, useState } from "react";

type Agent = {
  id: string;
  name: string;
  publicKey: string;
  strategy: string;
};

export function DashboardShell() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [status, setStatus] = useState<string>("No agents created yet.");
  const [loading, setLoading] = useState(false);

  const summary = useMemo(() => ({
    totalAgents: agents.length,
    treasury: agents.filter((item) => item.strategy === "treasury").length,
  }), [agents]);

  async function createAgent() {
    setLoading(true);
    setStatus("Creating agent wallet...");
    const response = await fetch("/api/agents/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: `Agent ${agents.length + 1}`,
        strategy: agents.length % 2 === 0 ? "treasury" : "rebalance",
      }),
    });
    const payload = await response.json();
    setAgents((prev) => [...prev, payload.agent]);
    setStatus(`Created ${payload.agent.name}.`);
    setLoading(false);
  }

  async function runScenario(agentId: string) {
    setLoading(true);
    setStatus("Running devnet scenario. This may take a moment.");
    const response = await fetch("/api/agents/run", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ agentId }),
    });
    const payload = await response.json();
    if (payload.error) {
      setStatus(payload.error);
    } else {
      setStatus("Scenario completed. Check logs and Explorer links from the API response.");
    }
    setLoading(false);
  }

  return (
    <div className="grid" style={{ gridTemplateColumns: "1.15fr 0.85fr", alignItems: "start" }}>
      <div className="card" style={{ padding: 28 }}>
        <div className="badge">Live demo dashboard</div>
        <h3 style={{ fontSize: 34, margin: "16px 0 10px" }}>Agent wallets with visible guardrails</h3>
        <p className="small" style={{ fontSize: 17, lineHeight: 1.8 }}>
          Create isolated wallets, run an autonomous devnet flow, and surface the blocked action judges want to see.
        </p>
        <div style={{ display: "flex", gap: 12, marginTop: 22, flexWrap: "wrap" }}>
          <button className="btn" onClick={createAgent} disabled={loading}>Create agent</button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 12, marginTop: 22 }}>
          <div className="card" style={{ padding: 18 }}>
            <div className="small">Agents</div>
            <div style={{ fontSize: 28, fontWeight: 700, marginTop: 4 }}>{summary.totalAgents}</div>
          </div>
          <div className="card" style={{ padding: 18 }}>
            <div className="small">Treasury</div>
            <div style={{ fontSize: 28, fontWeight: 700, marginTop: 4 }}>{summary.treasury}</div>
          </div>
          <div className="card" style={{ padding: 18 }}>
            <div className="small">Status</div>
            <div style={{ fontSize: 14, fontWeight: 600, marginTop: 10 }}>{loading ? "Running" : "Ready"}</div>
          </div>
        </div>
      </div>

      <div className="card" style={{ padding: 28 }}>
        <div className="small">Runtime notes</div>
        <p style={{ lineHeight: 1.8, marginTop: 10 }}>
          {status}
        </p>
        <div className="code" style={{ marginTop: 18 }}>
          <strong>Judge story</strong>
          <div style={{ marginTop: 10, lineHeight: 1.8 }}>
            1. Create a wallet programmatically.<br />
            2. Airdrop devnet SOL.<br />
            3. Mint demo SPL tokens.<br />
            4. Approve one safe transfer.<br />
            5. Reject one risky transfer before signing.
          </div>
        </div>
      </div>

      <div style={{ gridColumn: "1 / -1", marginTop: 20 }} className="card">
        <div style={{ padding: 28 }}>
          <div className="small">Agents</div>
          <div className="grid" style={{ marginTop: 16 }}>
            {agents.length === 0 ? (
              <div className="small">Create an agent to start the demo.</div>
            ) : agents.map((agent) => (
              <div key={agent.id} className="card" style={{ padding: 20, display: "flex", justifyContent: "space-between", gap: 16, alignItems: "center" }}>
                <div>
                  <div style={{ fontWeight: 700 }}>{agent.name}</div>
                  <div className="small" style={{ marginTop: 6 }}>{agent.publicKey}</div>
                  <div className="small" style={{ marginTop: 4 }}>Strategy: {agent.strategy}</div>
                </div>
                <button className="btn secondary" onClick={() => runScenario(agent.id)} disabled={loading}>
                  Run scenario
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
